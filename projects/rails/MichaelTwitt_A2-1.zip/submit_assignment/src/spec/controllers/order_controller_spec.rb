require 'rails_helper'

RSpec.describe OrderController, type: :controller do

end
